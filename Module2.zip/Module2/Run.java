public class Run {
    public static void main(String[] args) {
        app calculator = new app();
        calculator.setVisible(true);
    }
}