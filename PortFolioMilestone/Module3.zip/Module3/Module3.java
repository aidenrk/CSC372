import javafx.application.Application;

public class Module3 {
    public static void main(String[] args) {
        Application.launch(MainInt.class, args);
    }
}
